class Sample
{
public: void printname1();
	void printname();
private:
	int b,a;
	float a,b;
	
};


void main()
{
 float b;
 int x;
 bool xyz;
 
}
