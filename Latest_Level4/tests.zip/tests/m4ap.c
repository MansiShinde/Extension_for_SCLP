int a,b;

void main(){

  int c,d;

  int a1,a2;

  a1=1;

  a2=1;

  a=1;

  b=1;

  c=1;

  d=1;

  while(a1<=100){

    a=a+1;

    if(2>=3){

      a=a+1;

    }

    if(3>=2){

      a=a+1;

    }

    if(2<=3){

      a=a+1;

    }

    if(2!=3){

      a=a+1;

    }

    if(2==3){

      a=a+1;

    }

    if(4>=3){

      a=a+1;

    }


    do{

      a1=a1+1;

    }while(a1<=200);

    print a1;

  }

  print a;

}
