int a;
void main(){
    int a, b,c;
    bool x,y;
    x = b < 10;
    y = ! @x;
}
