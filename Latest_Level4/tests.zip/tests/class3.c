//multiple classes with only declarations and main function with variable declarations -- worked

class Sample
{
public: string abc;
	void printname();
private:
	int b;
	float x;
	
};

class Sample1
{
public: string abc;
	void printname();
private:
	int b;
	float x;
	
};


void main()
{
 float a;
}
