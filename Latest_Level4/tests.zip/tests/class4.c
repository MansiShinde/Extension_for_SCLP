//class with definitions and main function

class Sample
{
private: string abc;
	int a;
	void printname(){
	int b;float c;
	b = 50;	
	if(2!=3){
 	b=10;	
	}
	}
	
	void printname2(){
	int b;float c;
	b = 50;	
	if(2!=5){
 	b=10;	
	}
	}
};

void main()
{
 int a;
 a=10;
 a= 5+18;
}
