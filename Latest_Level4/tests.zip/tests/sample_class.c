
//single class with only class declarations and main function with only 1 variable declaration -- worked!!

class Sample
{

	
};


void main()
{
 float a;
}
