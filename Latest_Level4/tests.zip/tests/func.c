int f()
{
   int a;
  return a;
}
int g()
{

}
void main()
{
 
 f();
 g();

}
