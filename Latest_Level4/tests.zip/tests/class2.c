
// class with only declarations and main function with if-else statements -- worked 

class Sample
{
public: string abc;
	void printname();
private:
	int b;
	void name();
	
};


void main()
{
int x,y,a;
 
  if(x>y) {
	 a=x;
}
 else {
       a=y; 
}

}

void getname()
{
  int a, b;

}



